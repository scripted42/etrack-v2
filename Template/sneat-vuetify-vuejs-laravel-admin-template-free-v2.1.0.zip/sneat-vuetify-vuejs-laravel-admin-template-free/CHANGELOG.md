<!-- Available h3 headings: Added, Fixed, Updated, Removed, Deprecated -->

# Changelog

All notable changes to this template will be documented in this file

## v2.1.0 (2025-01-01)

### Updated

- Updated Vue, Vuetify & Laravel to the latest version

## v2.0.0 (2024-07-09)

### Updated

- Updated all dependencies and devDependencies to latest
- Updated layouts design
- Updated Laravel version to latest

## v1.0.0 (2023-06-01)

### Added

- Initial Release
